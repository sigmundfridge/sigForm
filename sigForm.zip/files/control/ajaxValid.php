<?php 
require('formClass.php');
 $ajaxObj = new ajaxValidator();
?>